# SmartCashly: 20-store research manifest

Generated on 27 July 2026. Customer-facing copy is original SmartCashly wording; competing cashback-site names are intentionally absent from store pages.

## Research-source mix

Greek and international cashback/deal sources were deliberately mixed rather than copying one catalogue:

- ApoPou (Greece): Kotsovolos, Public and related Greek-store offer checks.
- Picodi Greece / international editions: Puma, New Balance, FARFETCH and fashion-offer checks.
- TopCashback: Hotels.com, IKEA, Trip.com, travel and home-offer checks.
- Rakuten and other international cashback listings: travel and technology cross-checks.
- Official retailer pages: permanent departments, product categories, availability wording and destination links.

## Key source URLs

- https://apopou.gr/stores/kotsovolos
- https://apopou.gr/stores/public
- https://www.picodi.com/gr/puma
- https://www.picodi.com/gr/new-balance
- https://www.picodi.com/ch/farfetch
- https://www.topcashback.com/hotels-com/
- https://www.topcashback.com/ikea/
- https://www.topcashback.com/trip-com/
- https://www.udemy.com/courses/free/

## Implementation rules applied

- Every new store uses 1% SmartCashly cashback consistently.
- Main cashback card always appears first.
- No coupon card was created without a genuine visible code.
- Every normal offer card includes “+ Get Extra 1% Cashback”.
- Total cards vary by store from 3 to 8.
- Local PNG logo files are used for every store.
- Background particles remain behind cards and logos.
